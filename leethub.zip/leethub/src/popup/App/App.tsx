import React from 'react'
import Popup from '../../components/Popup'

const App: React.FC = () => {
  return (
    <div>
      <Popup />
    </div>
  )
}

export default App
