export const uploadState = { uploading: false };
