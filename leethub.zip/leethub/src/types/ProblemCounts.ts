export interface ProblemCounts {
  easy: number
  medium: number
  hard: number
}
