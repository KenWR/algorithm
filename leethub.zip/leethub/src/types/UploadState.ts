export interface UploadState {
  uploading: boolean
  countdown?: NodeJS.Timeout
}
