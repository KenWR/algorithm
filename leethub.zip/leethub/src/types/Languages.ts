export interface Languages {
  [key: string]: string
}
