export interface Stats {
  version?: string
  branches?: any
  submission?: any
  problems?: any
}
