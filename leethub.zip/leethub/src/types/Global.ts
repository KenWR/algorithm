export {}

declare global {
  interface Window {
    oAuth2: any
  }
}
