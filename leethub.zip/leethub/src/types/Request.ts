export interface Request {
  closeWebPage?: boolean
  isSuccess?: boolean
  username?: string
  token?: string
  sender?: string
  task?: string
  problemId?: number
}
