export const WELCOME_URL = `chrome-extension://${chrome.runtime.id}/index.html#/welcome`

