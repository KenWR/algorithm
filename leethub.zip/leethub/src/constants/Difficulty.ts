export type Difficulty = 'Easy' | 'Medium' | 'Hard' | ''
