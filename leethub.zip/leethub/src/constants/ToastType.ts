export enum ToastType {
  Danger = '#eb3b5a',
  Warning = '#fdcb6e',
  Success = '#00b894'
}
