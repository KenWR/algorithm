export enum ProblemType {
  NormalProblem = 0,
  ExploreSectionProblem = 1
}
