export const LocalAuth = {
  KEY: 'leethub_token',
  ACCESS_TOKEN_URL: 'https://github.com/login/oauth/access_token',
  AUTHORIZATION_URL: 'https://github.com/login/oauth/authorize',
  CLIENT_ID: 'a9eb2587e6d994e601c0',
  CLIENT_SECRET: '709f439874f035be71415011733f5eab789f6e31',
  REDIRECT_URL: 'https://github.com/',
  SCOPES: ['repo']
}
