export const README_MSG: string = 'Create README - LeetHub'
export const SUBMIT_MSG: string = 'Added solution - LeetHub'
export const UPDATE_MSG: string = 'Updated solution - LeetHub'
